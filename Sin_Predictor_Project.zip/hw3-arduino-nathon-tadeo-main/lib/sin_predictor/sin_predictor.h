#ifndef SIN_PREDICTOR_H
#define SIN_PREDICTOR_H

#include <Arduino.h>

// Declare the model array and its length
extern const unsigned char sin_predictor_tflite[];
extern const unsigned int sin_predictor_tflite_len;

#endif
